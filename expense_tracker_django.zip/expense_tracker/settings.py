# settings.py placeholder
INSTALLED_APPS = ['tracker',]